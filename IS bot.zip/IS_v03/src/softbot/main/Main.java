package softbot.main;

import java.util.Random;

import softbot.world.logic.MainPanel;

public class Main {
	public static void main(String[] args) {
		
		
		MainPanel panel = new MainPanel();

		MojBot player1 = new MojBot(panel);
		MojBot player2 = new MojBot(panel);
		player1.setNerprijatelj(player2);
		player2.setNerprijatelj(player1);

		panel.setPlayer1(player1);
		panel.setPlayer2(player2);

		panel.start();

	}
}
