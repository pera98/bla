package softbot.main;

import softbot.world.logic.Field;
import softbot.world.logic.MainPanel;
import softbot.world.logic.SoftBot;

public class TestBot extends SoftBot {
	public TestBot(MainPanel panel) {
		super(panel);
	}

	@Override
	public void play(Field[][] fields) {
	
		yield();
		
	}
}
