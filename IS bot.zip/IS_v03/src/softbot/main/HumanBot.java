package softbot.main;

import java.util.Scanner;

import softbot.world.logic.Direction;
import softbot.world.logic.Field;
import softbot.world.logic.MainPanel;
import softbot.world.logic.SoftBot;

public class HumanBot extends SoftBot {
	
	public HumanBot(MainPanel panel) {
		super(panel);
	}
	
	private void printField(Field[][] fields, int meY, int meX) {
		System.out.println("Energija: " + getEnergy());
		for (int i = 0; i < 5; i++) {
			for (int j = 0; j < 5; j++) {
				if (fields[i][j] == null) {
					System.out.print("|");
					continue;
				}
				if (fields[i][j].hasPlayer()) {
					if (meY == i && meX == j) {
						System.out.print(fields[i][j].hasFood() ? "0" : "O");
					} else {
						System.out.print("X");
					}
				} else if (fields[i][j].hasFood()) {
					System.out.print('*');
				} else {
					System.out.print('.');
				}
			}
			System.out.println();
		}
	}


	@Override
	public void play(Field[][] fields) {
		int meY = 2, meX = 2;
		Scanner sc = new Scanner(System.in);
dow:	do {
			printField(fields, meY, meX);
			System.out.println("Akcije: mU, mD, mL, mR, sU, sD, sL, sR, e, n");
			System.out.print("Unesite akciju: ");
			String akcija = sc.nextLine().trim();
			if (akcija.isEmpty())
				break;
			switch(akcija.charAt(0)) {
			case 'm': {
				if (akcija.length() < 2)
					break;
				switch (akcija.charAt(1)) {
				case 'U': move(Direction.UP); meY--; break;
				case 'D': move(Direction.DOWN); meY++; break;
				case 'L': move(Direction.LEFT); meX--; break;
				case 'R': move(Direction.RIGHT); meX++; break;
				default: break dow;
				}
				break;
			}
			case 's': {
				if (akcija.length() < 2)
					break;
				if (akcija.length() < 2)
					break;
				switch (akcija.charAt(1)) {
				case 'U': shoot(Direction.UP); break;
				case 'D': shoot(Direction.DOWN); break;
				case 'L': shoot(Direction.LEFT); break;
				case 'R': shoot(Direction.RIGHT); break;
				default: break dow;
				}
				break;
			}
			case 'e': {
				eat();
				break;
			}
			default: {
				break dow;
			}
			}
		} while (true);
		yield();
	}

}
