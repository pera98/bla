package softbot.main;

import java.util.Random;

import softbot.world.logic.Direction;
import softbot.world.logic.Field;
import softbot.world.logic.MainPanel;
import softbot.world.logic.SoftBot;

public class MojBot extends SoftBot{

	public MojBot(MainPanel panel) {
		super(panel);
	}

	@Override
	public void play(Field[][] fields) {

		if(isEnemyUp()) {
			if(getEnergy()>getNerprijatelj().getEnergy()) shoot(Direction.UP);
			else pomeriSeGdeGod();
		}
		else if(isEnemyDown()) {
			if(getEnergy()>getNerprijatelj().getEnergy()) shoot(Direction.DOWN);
			else pomeriSeGdeGod();
		}
		else if(isEnemyLeft()) {
			if(getEnergy()>getNerprijatelj().getEnergy()) shoot(Direction.LEFT);
			else pomeriSeGdeGod();
		}
		else if(isEnemyRight()) {
			if(getEnergy()>getNerprijatelj().getEnergy()) shoot(Direction.RIGHT);
			else pomeriSeGdeGod();
		}
		else
		{
			if(isLeft(fields)) move(Direction.LEFT);
			else if(isRight(fields)) move(Direction.RIGHT);
			else if(isUp(fields)) move(Direction.UP);
			else if(isDown(fields)) move(Direction.DOWN);
			else pomeriSeGdeGod();
		}

		
		if(getPanel().getBoard()[getPosY()][getPosX()].hasFood()) eat();
		System.out.println("Energija " + getName()+" : " + getEnergy());
		
		yield();
	}
	
	private boolean isRight(Field[][] fields)
	{
		for(int j=3;j<5;j++)
		{
			if(fields[2][j]!=null &&fields[2][j].hasFood()) return true;
		}
		return false;
	}
	private boolean isLeft(Field[][] fields)
	{
		for(int j=0;j<2;j++)
		{
			if(fields[2][j]!=null &&fields[2][j].hasFood()) return true;
		}
		return false;
	}
	private boolean isDown(Field[][] fields)
	{
		for(int i=3;i<5;i++)
		{
			for(int j=0;j<5;j++)
			{
				if(fields[i][j]!=null && fields[i][j].hasFood()) return true;
			}
		}
		return false;
	}
	private boolean isUp(Field[][] fields)
	{
		for(int i=0;i<2;i++)
		{
			for(int j=0;j<5;j++)
			{
				if(fields[i][j]!=null && fields[i][j].hasFood()) return true;
			}
		}
		return false;
	}
	private boolean isEnemyUp()
	{
		if(getNerprijatelj().getPosX()==getPosX() && 
				getNerprijatelj().getPosY()<getPosY()) return true;
		return false;
	}
	private boolean isEnemyDown()
	{
		if(getNerprijatelj().getPosX()==getPosX() && 
				getNerprijatelj().getPosY()>getPosY()) return true;
		return false;
	}
	private boolean isEnemyLeft()
	{
		if(getNerprijatelj().getPosX()<getPosX() && 
				getNerprijatelj().getPosY()==getPosY()) return true;
		return false;
	}
	private boolean isEnemyRight()
	{
		if(getNerprijatelj().getPosX()>getPosX() && 
				getNerprijatelj().getPosY()==getPosY()) return true;
		return false;
	}
	
	private void pomeriSeGdeGod()
	{
		Random r=new Random();
		int random=r.nextInt(4)+1;
		switch(random) {
		case 1:move(Direction.UP);
		break;
		case 2:move(Direction.DOWN);
		break;
		case 3:move(Direction.LEFT);
		break;
		case 4:move(Direction.RIGHT);
		break;
		}
	}
}
