package softbot.world.logic;

public enum Direction {
	UP, DOWN, LEFT, RIGHT
}
