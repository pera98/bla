package softbot.world.logic;

import java.util.Random;

public class MainPanel {

	public static final int SIZE = 20;
	public static final int STARTING_HEALTH = 50;
	public static final int FOOD_GAIN = 50;
	public static final int SHOOT_REDUCE = 10;
	public static final int HIT_REDUCE = 20;
	public static final int MOVE_REDUCE = 5;
	public static final int STARVE_REDUCE = 1;
	public static final int FOOD_PROBABILITY = 20;

	// private BufferedImage img;
	private Random r = new Random();
	private Field[][] board;
	private SoftBot player1;
	private SoftBot player2;
	private int moveCount = 0;
	
	private boolean player1Turn = true;

	
	public MainPanel() {
		board = new Field[SIZE][SIZE];

		for (int i = 0; i < SIZE; i++) {
			for (int j = 0; j < SIZE; j++) {
				board[i][j] = new Field();
				if (r.nextInt(100) < FOOD_PROBABILITY) {
					board[i][j].setHasFood(true);
				}
			}
		}
	}

	public final void setPlayer1(SoftBot player1) {
		this.player1 = player1;
		this.player1.setName("Player 1");
		int x = 0, y = 0;
		do {
			x = r.nextInt(SIZE);
			y = r.nextInt(SIZE);
		} while (!setPlayerPosition(player1, x, y));
	}

	public final void setPlayer2(SoftBot player2) {
		this.player2 = player2;
		this.player2.setName("Player 2");
		int x = 0, y = 0;
		do {
			x = r.nextInt(SIZE);
			y = r.nextInt(SIZE);
		} while (!setPlayerPosition(player2, x, y));
	}
	
	private void printField() {
		for (int i = 0; i < SIZE; i++) {
			for (int j = 0; j < SIZE; j++) {
				if (board[i][j].hasPlayer()) {
					String pName = board[i][j].getPlayer().getName(); 
					System.out.print(pName.substring(pName.length()-1));
				} else if (board[i][j].hasFood()) {
					System.out.print('*');
				} else {
					System.out.print('.');
				}
			}
			System.out.println();
		}
	}

	public final void yield(SoftBot b) {
		if ((player1Turn && !b.getName().equals("Player 1")) || (!player1Turn && !b.getName().equals("Player 2"))) {
			System.err.println(b.getName() + " already yielded.");
			return;
		}

		if (player1.isDead() && player2.isDead()) {
			System.out.println("Round draw!");
			return;
		} else if (player1.isDead()) {
			System.out.println("Player 2 wins");
			return;
		} else if (player2.isDead()) {
			System.out.println("Player 1 wins");
			return;
		}

		printField();

		
		try {
			Thread.sleep(1500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		System.out.println(b.getName() + " yielded.");
		System.out.println("--------------------------------------------------------------");
		moveCount++;
		if (moveCount % FOOD_PROBABILITY == 0) {
			int i = r.nextInt(SIZE), j = r.nextInt(SIZE);
			board[i][j].setHasFood(true);
		}

		if (player1Turn) {
			reduceHealth(player1, STARVE_REDUCE);
			player1Turn = false;
			player2.play(getFieldsAround(player2));
		} else {
			reduceHealth(player2, STARVE_REDUCE);
			player1Turn = true;
			player1.play(getFieldsAround(player1));
		}
	}

	private boolean reduceHealth(SoftBot b, int health) {
		b.setEnergy(b.getEnergy() - health);
		if (b.getEnergy() < 0) {
			b.setEnergy(0);
			b.setDead(true);
		}
		return !b.isDead();
	}

	public boolean move(SoftBot b, Direction d) {
		System.out.println(b.getName() +" Moving " + d);
		int addX = 0, addY = 0;
		switch (d) {
		case UP:
			addY = -1;
			break;
		case DOWN:
			addY = 1;
			break;
		case LEFT:
			addX = -1;
			break;
		case RIGHT:
			addX = 1;
			break;
		}

		boolean ret = setPlayerPosition(b, b.getPosX() + addX, b.getPosY() + addY);
		if (ret) {
			if (!reduceHealth(b, MOVE_REDUCE)) {
				System.err.println("Softbot starved while trying to move :(");
				return false;
			}
		}
		return ret;
	}

	private boolean setPlayerPosition(SoftBot b, int x, int y) {
		if (x < 0 || y < 0 || x >= SIZE || y >= SIZE) {
			return false;
		}
		if ((player1 != null && x == player1.getPosX() && y == player1.getPosY())
				|| (player2 != null && x == player2.getPosX() && y == player2.getPosY())) {
			System.err.println("Attempt to place a bot over another one!");
			return false;
		}

		Field f = board[b.getPosY()][b.getPosX()];
		f.setPlayer(null);
		b.setPosX(x);
		b.setPosY(y);
		f = board[b.getPosY()][b.getPosX()];
		f.setPlayer(b);
		return true;
	}

	public boolean shoot(SoftBot b, Direction d) {
		int addX = 0, addY = 0;
		switch (d) {
		case UP:
			addY = -1;
			break;
		case DOWN:
			addY = 1;
			break;
		case LEFT:
			addX = -1;
			break;
		case RIGHT:
			addX = 1;
			break;
		}

		int x = b.getPosX() + addX, y = b.getPosY() + addY;
		if (!reduceHealth(b, SHOOT_REDUCE)) {
			System.err.println(b.getName() + " starved while trying to shoot :(");
			return false;
		}
		for (; x < SIZE && y < SIZE && x >= 0 && y >= 0; x += addX, y += addY) {
			if (board[y][x].hasPlayer()) {
				SoftBot bot = board[y][x].getPlayer();
				if (!reduceHealth(bot, HIT_REDUCE)) {
					System.err.println(bot.getName() + " was killed by " + b.getName());
				}
				System.out.println(b.getName()+" je upucao " + bot.getName());
				return true;
			}
		}
		return false;
	}

	private Field[][] getFieldsAround(SoftBot b) {
		Field[][] ret = new Field[5][5];
		int ii = b.getPosY(), jj = b.getPosX();
		for (int i = 0; i < 5; i++) {
			for (int j = 0; j < 5; j++) {
				if (ii + i - 2 < 0 || ii + i - 2 >= SIZE || jj + j - 2 < 0 || jj + j - 2 >= SIZE) {
					ret[i][j] = null;
				} else
					ret[i][j] = board[ii + i - 2][jj + j - 2];
			}
		}
		return ret;
	}

	public boolean pickUp(SoftBot b) {
		if (board[b.getPosY()][b.getPosX()].hasFood()) {
			board[b.getPosY()][b.getPosX()].setHasFood(false);
			b.setEnergy(b.getEnergy() + FOOD_GAIN);
			System.out.println(b.getName()+" je pojeo hranu");
			return true;
		}
		return false;
	}

	public void start() {
		player1.play(getFieldsAround(player1));
	}
	public Field[][] getBoard() {
		return board;
	}
	public SoftBot getPlayer1() {
		return player1;
	}
}
