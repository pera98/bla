package softbot.world.logic;

public abstract class SoftBot {
	private MainPanel panel;
	private int energy = MainPanel.STARTING_HEALTH;
	private int posX, posY;
	private boolean dead = false;
	private String name;
	private SoftBot nerprijatelj;
	
	public SoftBot(MainPanel panel){
		this.panel = panel;
		
	}
	
	public final String getName() {
		return name;
	}
	
	
	final void setName(String name) {
		this.name = name;
	}
	
	final void setPosX(int posX) {
		this.posX = posX;
	}
	
	final void setPosY(int posY) {
		this.posY = posY;
	}
	
	public final int getPosX() {
		return posX;
	}
	
	public final int getPosY() {
		return posY;
	}
	
	public final int getEnergy() {
		return energy;
	}
	
	final void setEnergy(int energy) {
		this.energy = energy;
	}
	
	final boolean isDead() {
		return dead;
	}
	
	final void setDead(boolean dead) {
		this.dead = dead;
	}
	
	public final boolean shoot(Direction d){
		return panel.shoot(this, d);
	}
	
	public final boolean move(Direction d){
		return panel.move(this, d);
	}
	
	public final void yield(){
		panel.yield(this);
	}
	
	public final boolean eat(){
		return panel.pickUp(this);
	}
	
	public abstract void play(Field[][] fields);
	
	public MainPanel getPanel() {
		return panel;
	}
	public SoftBot getNerprijatelj() {
		return nerprijatelj;
	}
	public void setNerprijatelj(SoftBot nerprijatelj) {
		this.nerprijatelj = nerprijatelj;
	}
}
