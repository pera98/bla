package softbot.world.logic;

public class Field {
	private boolean hasFood = false;
	private SoftBot player = null;
	
	public boolean hasFood() {
		return hasFood;
	}
	
	public void setHasFood(boolean hasFood) {
		this.hasFood = hasFood;
	}
	
	public boolean hasPlayer(){
		return player != null;
	}
	
	public void setPlayer(SoftBot player) {
		this.player = player;
	}
	
	SoftBot getPlayer() {
		return player;
	}
	
	public boolean isEmpty(){
		return !hasFood() && !hasPlayer();
	}
	
	@Override
	public String toString() {
		if(hasPlayer()) return "player";
		if(hasFood()) return "food";
		return "empty";
	}
}
